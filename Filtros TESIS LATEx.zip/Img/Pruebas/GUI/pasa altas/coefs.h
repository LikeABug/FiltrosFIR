#include "tmwtypes.h"
const int BL = 17;
const int16_T B[17] = {0, 109, 335, -626, -717, 2071, 1118, -9419, 15563, -9419, 1118, 2071, -717, -626, 335, 109, 0};
#define BUFFER_SIZE 17
